import { IPartner } from "./IPartner";

export interface IPartners{
    [key: number]: IPartner;
}